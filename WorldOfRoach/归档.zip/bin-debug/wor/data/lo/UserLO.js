var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
/**
 * User
 * @author ResEncryption_nodep
 */
var UserLO = (function () {
    function UserLO() {
    }
    return UserLO;
}());
__reflect(UserLO.prototype, "UserLO");
//# sourceMappingURL=UserLO.js.map