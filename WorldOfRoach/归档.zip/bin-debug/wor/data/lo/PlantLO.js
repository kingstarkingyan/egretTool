var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
/**
   * Plant
   * @author ResEncryption_nodep
   */
var PlantLO = (function () {
    function PlantLO() {
    }
    return PlantLO;
}());
__reflect(PlantLO.prototype, "PlantLO");
//# sourceMappingURL=PlantLO.js.map