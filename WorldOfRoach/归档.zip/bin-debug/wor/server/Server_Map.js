var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var Server_Map = (function () {
    function Server_Map() {
    }
    return Server_Map;
}());
Server_Map.T_MAP_BASE = "T_MAP_BASE";
Server_Map.T_MAP_PLANTS = "T_MAP_PLANTS";
Server_Map.T_MAP_MINI = "T_MAP_MINI";
__reflect(Server_Map.prototype, "Server_Map");
//# sourceMappingURL=Server_Map.js.map