/**
 * 可以逐帧调用的接口,参考RenderManager
 * @author nodep
 * @version 1.0
 */
interface IRender {
	renderUpdate(interval:number);
}