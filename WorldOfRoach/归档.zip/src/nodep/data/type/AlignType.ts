/**
 * 对齐方式
 * @author nodep
 */
class AlignType {
	public static TOP_LEFT:string = "TOP_LEFT";
	public static TOP_CENTER:string = "TOP_CENTER";
	public static TOP_RIGHT:string = "TOP_RIGHT";
	public static CENTER:string = "CENTER";
	public static BOTTOM_LEFT:string = "BOTTOM_LEFT";
	public static BOTTOM_CENTER:string = "BOTTOM_CENTER";
	public static BOTTOM_RIGHT:string = "BOTTOM_RIGHT";
	public static NONE:string = "NONE";
}