/**当前地形 */
class StandType {
	public constructor() {
	}
	public static SEA:number = 1;
	public static LAND:number = 2;
	public static LAKE:number = 3;
}