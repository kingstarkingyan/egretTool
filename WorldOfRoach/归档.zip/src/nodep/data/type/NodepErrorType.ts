/**
 * 框架错误类型
 */
class NodepErrorType {
	public static LAYER_NO_EXISTENT: string = "LAYER_NO_EXISTENT";
	public static PARAM_TYPE_ERROR: string = "PARAM_TYPE_ERROR";
	public static ERROR_CODE:string = "ERROR_CODE";
}