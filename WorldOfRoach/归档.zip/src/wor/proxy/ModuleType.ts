/**
 * 模块分类
 */
class ModuleType {
	/**
	 * 玩家信息基础
	 */
	public static USER:number = 1;
}