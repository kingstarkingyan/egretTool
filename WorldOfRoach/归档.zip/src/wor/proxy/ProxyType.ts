/**
 * 协议号
 * 模块号+三位协议号
 */
class ProxyType {
	//获取玩家历史数据
	public static USER_GETHISTORY:number = 1001;
	//玩家进入游戏
	public static USER_ENTERGAME:number = 1002;
	//创建角色信息
	public static USER_CREATE:number = 1003;
}