/**
   * Plant
   * @author ResEncryption_nodep
   */
class PlantLO {
    public id: number;
    public name: string;
    public type: number;
    public lv: number;
    public pdct: string;
    public herit: string;
    public need: number;
    public end: number;
    public hp: number;
}
