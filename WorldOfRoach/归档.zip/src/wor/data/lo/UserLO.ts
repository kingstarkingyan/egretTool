
/**
 * User
 * @author ResEncryption_nodep
 */
class UserLO {
    public id: number;
    public name: string;
    public hpMax: number;
    public fullMax: number;
    public lkMax: number;
}
