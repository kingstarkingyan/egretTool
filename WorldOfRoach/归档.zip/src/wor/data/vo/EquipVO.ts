/**玩家装备*/
class EquipVO {
	public id:number;
	public type:number;
	public sun:number;
	public name:string;
	public icon:string;
}