/**道具*/
class ItemVO {
	public id:number;
	public name:number;
	public icon:number;
	public fun:number;//功能
}