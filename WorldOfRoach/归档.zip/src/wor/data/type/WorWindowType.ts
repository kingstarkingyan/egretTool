class WorWindowType extends WindowType{
    public static MENU_WINDOW:string = "MENU_WINDOW";//登陆界面的菜单
    public static ROCKER_LEFT:string = "ROCKER_LEFT";//摇杆
    public static TOP_TOOLBAR:string = "TOP_TOOLBAR";//右上角导航
    public static BOTTOM_TOOLBAR:string = "BOTTOM_TOOLBAR";//正下方导航
    public static LOG_WINDOW:string = "LOG_WINDOW";//日志任务记录界面
    public static MINI_MAP:string = "MINI_MAP";//小地图
    public static OPT_MAP:string = "OPT_MAP";//设置界面
    public static CURB_BAR:string = "CURB_BAR";//右手操作区
    public static ROLE_WINDOW:string = "ROLE_WINDOW";//左上角角色属性区
    public static MAIN_LOADING:string = "MAIN_LOADING";//游戏主加载界面
}