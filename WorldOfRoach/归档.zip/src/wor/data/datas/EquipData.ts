/**
 * 装备数据
 */
class EquipData {
	/**
	 * 位置:装备
	 */
	public posMap:Map<number,EquipVO> = new Map();

	//初始化位置列表
	public constructor(){
		
	}
}