/**
 * 河流
 */
class River {
	public startArea:Area2D;
	public downsteams:Array<AreaPoint> = new Array<AreaPoint>();
}