/**
 * 服务端维护的一个tiledWorld世界
 */
class TiledWorld {
	public constructor() {
		
	}
}