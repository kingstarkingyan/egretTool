class Server_Map {
	public static T_MAP_BASE:string = "T_MAP_BASE";
	public static T_MAP_PLANTS:string = "T_MAP_PLANTS";
	public static T_MAP_MINI:string = "T_MAP_MINI";

	public constructor() {
	}
}